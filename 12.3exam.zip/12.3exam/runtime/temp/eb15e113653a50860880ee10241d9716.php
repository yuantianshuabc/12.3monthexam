<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:83:"C:\Users\Lenovo\Desktop\12.3exam\public/../application/admin\view\goods\create.html";i:1606980757;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
<form action="<?php echo url('admin/Goods/save'); ?>" method="post" enctype="multipart/form-data">
    <h1>欢迎<?php echo \think\Session::get('user.username'); ?>添加图片</h1>
    图片标题：<input type="text" name="title"><br>
    图片分类： <select name="type" id="">
    <?php foreach($type as $v): ?>
    <option value="<?php echo $v['id']; ?>"><?php echo $v['type_name']; ?></option>
    <?php endforeach; ?>
</select><br>
    图片上传：<input type="file" name="images"><br>
    <input type="submit" value="上传">
</form>
</body>
</html>