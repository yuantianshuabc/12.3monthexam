<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:82:"C:\Users\Lenovo\Desktop\12.3exam\public/../application/admin\view\goods\index.html";i:1606986366;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<link rel="stylesheet" href="https://cdn.staticfile.org/twitter-bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://cdn.staticfile.org/jquery/2.1.1/jquery.min.js"></script>
<script src="https://cdn.staticfile.org/twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>
<style>
    .floor{
        width: 25%;
        float: left;
        text-align: center;
        margin: 35px 0px;
    }
    .paginate{
        text-align: center;
    }
    .type{
        width: 100%;
        height: 50px;
    }
</style>
<body>
<h1><?php echo \think\Session::get('user.username'); ?>的相册<span><a href="<?php echo url('admin/Goods/loginOut'); ?>">注销</a></span></h1>
<div class="type">
    <form action="<?php echo url('admin/Goods/index'); ?>" method="post">
        图片分类
        <select name="type" id="">
            <option value="">请选择分类</option>
            <?php foreach($type as $val): ?>
            <option value="<?php echo $val['id']; ?>"><?php echo $val['type_name']; ?></option>
            <?php endforeach; ?>
        </select>
        描述：<input type="text" name="title">
        <input type="submit" value="查询">
        <a href="<?php echo url('admin/Goods/create'); ?>">上传相册</a>
    </form>

</div>

<?php foreach($data as $v): ?>
<div class="floor">
    <img width="40%" height="200px" src="/uploads/<?php echo $v['url']; ?>" alt="">
</div>
<?php endforeach; ?>
<div class="paginate"><?php echo $data->render(); ?></div>

</body>
</html>