<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:82:"C:\Users\Lenovo\Desktop\12.3exam\public/../application/admin\view\login\login.html";i:1606978793;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
<form action="<?php echo url('admin/Login/loginDo'); ?>" method="post">
    用户名：<input type="text" name="username"><br>
    密码：<input type="password" name="password"><br>
    验证码：<input type="text" name="captcha">
    <div ><?php echo captcha_img(); ?></div>
    <input type="submit" value="登录">
</form>
</body>
</html>