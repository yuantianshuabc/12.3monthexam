<?php

namespace app\admin\controller;

use app\common\model\User;
use think\Controller;

class Login extends TokenCheck
{
//    登录页面
    public function index(){
        return view('login');
    }
//    登录
    public function loginDo(){
//        接收数据
        $param=input();
//        数据验证
        $validate = $this->validate($param,[
           'username|用户名'=>'require',
           'password|密码'=>'require',
            'captcha|验证码'=>'require|captcha'
        ]);
        if (true !== $validate){
            return $this->error($validate);
        }
//        查询
        $data = User::where('username',$param['username'])->where('password',md5(md5($param['password'])))->find();
        if ($data){
            $userid=$data['id'];
            $token = $this->createToken($userid);
            session('token',$token);
            session('user',$data);
            return  $this->redirect('admin/Goods/index');
        }else{
            $this->error('用户名或密码错误');
        }
    }
}
