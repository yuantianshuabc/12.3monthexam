<?php


namespace app\admin\controller;


use think\Controller;

class TokenCheck extends Controller
{
    /**
     * 生成用户token,保持登陆
     * @param  $userid  int      用户id
     * @return $token   string   用户token
     */
    public function createToken( $userid ){
        $token=$userid.'_'.MD5( $userid.uniqid().rand( 00000000,99999999 ) );
        $file_dir = ROOT_PATH."public".DS."apitoken".DS.$userid.DS;
        if( !file_exists( $file_dir ) )
        {
            mkdir($file_dir,0777,true);
        }else
        {
            //删除之前的token文件
            $file_token = scandir( $file_dir );
            foreach ( $file_token as $k => $v ) {
                if($v == '.' || $v == '..'){}else
                {
                    unlink($file_dir.$v);
                }
            }
        }
        $fh = fopen( $file_dir.$token,'w' );
        fwrite( $fh,serialize( array( 'time'=>time(),'token'=>$token,'user_id'=>$userid ) ) );
        fclose( $fh );
        return $token;
    }
    /**
     * 登陆验证,利用token获取用户id
     * @param  $token   string   用户token
     * @return [type]   user_id  用户id
     */
    public function getToken( $token )
    {
        $maxtime = 86400 * 3;  //3天过期时间,单位是秒
        $fcode = array();
        $user_id = strstr($token, "_", true);  //取到用户id
        $file_dir = ROOT_PATH . "public" . DS . "apitoken" . DS . $user_id . DS;  //找到token所在目录
        $file = $file_dir . $token; //找到token文件夹
        //token存在的情况
        if (file_exists($file)) {
            $fh = @fopen($file, 'r');
            //反序列化出token文件数据,等到time,token,userid;
            $fcode = unserialize(@fread($fh, filesize($file)));
            @fclose($fh);
            if ($fcode['time'] + $maxtime < time()) {
                //3天未登录过期,过期后删除token文件
                @unlink($file);
                return ['code' => -1000, 'msg' => 'token过期,请重新登陆'];
            } else {
                //没有过期,过期时间重新计算,避免用户3天登陆一次
                $user_id = $fcode['user_id'];
                $fh1 = fopen($file, 'w');
                //重新写入当前时间,确保3天以内登陆的用户一直不需要重新登陆
                fwrite($fh1, serialize(array('time' => time(), 'token' => $token, 'user_id' => $user_id)));
                fclose($fh1);
                return $user_id;
            }
        } else {
            return ['code' => -1001, 'msg' => 'token不存在,请先登陆'];
        }
    }
    }