<?php

namespace app\admin\controller;

use app\common\model\Images;
use app\common\model\Type;
use think\Controller;

class Goods extends Base
{
//    图片列表
    public function index(){
//        接收参数
        $type=input('type');
        $title=input('title');
        //        获取用户id
        $user_id=session('user.id');
//        调用封装的方法，查图片
       $data=selectImages($user_id,$type,$title);
//       分类
        $type = Type::select();
//        渲染视图
        return view('index',['data'=>$data,'type'=>$type]);
    }
//    添加图片列表
    public function create(){
        $type = Type::select();
        return view('create',['type'=>$type]);
    }
//    添加图片
    public function save(){
//        接收数据
        $param=input();
//        验证数据
        $result = $this->validate($param,[
           'title|标题' => 'require',
           'type|分类' => 'require'
        ]);
        if (true !== $result){
            return $this->error($result);
        }
        // 获取表单上传文件 例如上传了001.jpg
        $file = request()->file('images');
        // 移动到框架应用根目录/public/uploads/ 目录下
        $info = $file->validate(['ext'=>'jpg,png,gif'])->move(ROOT_PATH . 'public' . DS . 'uploads');
        if($info){
            // 成功上传后 获取上传信息
            // 输出 20160820/42a79759f284b767dfcb2a0197904287.jpg
            $param['url'] = $info->getSaveName();
        }else{
            // 上传失败获取错误信息
            return $file->getError();
        }
//        用户id
        $param['uid']=session('user.id');
//        添加入库
        $data = model('Images')->data($param)->allowField(true)->save();
        if ($data){
//            成功跳转列表
            return  $this->redirect("admin/Goods/index");
        }else{
            return  $this->error('系统繁忙请稍后再试');
        }
    }
//    注销登录
    public function loginOut(){
        session('user',null);
        return redirect('admin/Login/index');
    }
}
