<?php
if (!function_exists("selectImages")){
    function selectImages($user_id,$type,$title){
        $where=[];
        if (!empty($type)){
            $where['type']=$type;

        }
        if (!empty($title)){
            $where['title']=$title;
        }
        $where['uid']=$user_id;
        $data = model('Images')->where($where)->paginate(8);
        return $data;
    }
}