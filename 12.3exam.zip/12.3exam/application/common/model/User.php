<?php

namespace app\common\model;

use think\Model;

class User extends Model
{
    //
}
